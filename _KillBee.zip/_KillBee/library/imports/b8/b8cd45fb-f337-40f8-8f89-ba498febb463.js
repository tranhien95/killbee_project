"use strict";
cc._RF.push(module, 'b8cd4X78zdA+I+JukmP67Rj', 'BulletEnemy');
// scripts/BulletEnemy.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ObjectBase_1 = require("./ObjectBase");
var MyUtils_1 = require("./MyUtils");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BulletEnemy = /** @class */ (function (_super) {
    __extends(BulletEnemy, _super);
    function BulletEnemy() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BulletEnemy.prototype.SetInfo = function (x, y, vec, v) {
        this.node.x = x;
        this.node.y = y;
        this.veloc = v;
        this.vec = vec;
    };
    BulletEnemy.prototype.update = function (dt) {
        this.node.x += this.vec.x * this.veloc * dt;
        this.node.y += this.vec.y * this.veloc * dt;
        MyUtils_1.default.CheckOutScreenDestroy(this.node);
    };
    BulletEnemy = __decorate([
        ccclass
    ], BulletEnemy);
    return BulletEnemy;
}(ObjectBase_1.ObjectBase));
exports.default = BulletEnemy;

cc._RF.pop();