"use strict";
cc._RF.push(module, '89538GkJVlKiKQJ3f1IA7Fo', 'Enum');
// scripts/Enum.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GAME_STATE;
(function (GAME_STATE) {
    GAME_STATE[GAME_STATE["START"] = 0] = "START";
    GAME_STATE[GAME_STATE["LEVEL"] = 1] = "LEVEL";
    GAME_STATE[GAME_STATE["LEVEL_INFO"] = 2] = "LEVEL_INFO";
    GAME_STATE[GAME_STATE["GAME"] = 3] = "GAME";
    GAME_STATE[GAME_STATE["END"] = 4] = "END";
})(GAME_STATE = exports.GAME_STATE || (exports.GAME_STATE = {}));
var PLAYER_STATE;
(function (PLAYER_STATE) {
    PLAYER_STATE[PLAYER_STATE["NONE"] = 0] = "NONE";
    PLAYER_STATE[PLAYER_STATE["IDLE"] = 1] = "IDLE";
    PLAYER_STATE[PLAYER_STATE["BURST"] = 2] = "BURST";
    PLAYER_STATE[PLAYER_STATE["DIE"] = 3] = "DIE";
})(PLAYER_STATE = exports.PLAYER_STATE || (exports.PLAYER_STATE = {}));
var ENEMY_STATE;
(function (ENEMY_STATE) {
    ENEMY_STATE[ENEMY_STATE["NONE"] = 0] = "NONE";
    ENEMY_STATE[ENEMY_STATE["IDLE"] = 1] = "IDLE";
    ENEMY_STATE[ENEMY_STATE["FIRE"] = 2] = "FIRE";
    ENEMY_STATE[ENEMY_STATE["BURST"] = 3] = "BURST";
    ENEMY_STATE[ENEMY_STATE["DIE"] = 4] = "DIE";
})(ENEMY_STATE = exports.ENEMY_STATE || (exports.ENEMY_STATE = {}));
var COLLIDER_TAG;
(function (COLLIDER_TAG) {
    COLLIDER_TAG[COLLIDER_TAG["NONE"] = 0] = "NONE";
    COLLIDER_TAG[COLLIDER_TAG["PLAYER"] = 1] = "PLAYER";
    COLLIDER_TAG[COLLIDER_TAG["ENEMY"] = 2] = "ENEMY";
    COLLIDER_TAG[COLLIDER_TAG["BULLET"] = 3] = "BULLET";
    COLLIDER_TAG[COLLIDER_TAG["BULLET_ENEMY"] = 4] = "BULLET_ENEMY";
})(COLLIDER_TAG = exports.COLLIDER_TAG || (exports.COLLIDER_TAG = {}));

cc._RF.pop();