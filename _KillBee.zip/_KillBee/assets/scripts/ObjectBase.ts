const { ccclass, property } = cc._decorator;
@ccclass
export class ObjectBase extends cc.Component
{
    protected width: number;
    protected height: number;
    protected health: number;
    protected veloc: number;

    protected Init(){}
    protected Reset(){}
    protected SetDie(){}
    protected IsDie(){}
    public GetHealth(){return this.health;}
}