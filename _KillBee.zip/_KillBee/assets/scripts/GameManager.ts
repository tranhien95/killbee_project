import Player from "./Player";
import GlobalDefines from "./GlobalDefines";
import Bullet from "./Bullet";
import { GAME_STATE, ENEMY_STATE, PLAYER_STATE } from "./Enum";
import Enemy from "./Enemy";
import BulletEnemy from "./BulletEnemy";

const {ccclass, property} = cc._decorator;

@ccclass
export default class GameManager extends cc.Component {

    @property(Player)
    private player: Player = null;
    @property(cc.Node)
    private nodeEnemy: cc.Node = null;
    @property(cc.Node)
    private nodeBullet: cc.Node = null;
    @property(cc.Node)
    private nodeBulletEnemy: cc.Node = null;
    @property(cc.Prefab)
    private prefabEnemy: cc.Prefab = null;
    @property(cc.Prefab)
    private prefabBullet: cc.Prefab = null;
    @property(cc.Prefab)
    private prefabBulletEnemy: cc.Prefab = null;
    @property(cc.Label)
    private lblScore:cc.Label = null;
    @property([cc.Node])
    nodeHealthArr: cc.Node[] = [];
    @property(cc.Node)
    private nodeStart:cc.Node = null;
    @property(cc.Node)
    private nodeLevel:cc.Node = null;
    @property(cc.Node)
    private nodeLevelInfo:cc.Node = null;
    @property(cc.Node)
    private nodeGame:cc.Node = null;
    @property(cc.Node)
    private nodeEnd:cc.Node = null;
    @property(cc.Node)
    private infoLv1:cc.Node = null;
    @property(cc.Node)
    private infoLv2:cc.Node = null;
    @property(cc.Node)
    private infoLv3:cc.Node = null;
    @property(cc.Label)
    private lblTimer:cc.Label = null;
    @property(cc.Node)
    private nodeGameWin:cc.Node = null;
    @property(cc.Node)
    private nodeGameLose:cc.Node = null;
    @property(cc.Label)
    private lblScoreEnd:cc.Label = null;

    static Defines: GlobalDefines = new GlobalDefines();
    private keys : Map<number,boolean> = new Map();
    private state: GAME_STATE = GAME_STATE.START;
    private score: number = 0;
    private level: number = 0;
    private timer: number = 0;
    private bulletEnemyVeloc: number = 0;

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN,
            this.onKeyDown,this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP,
            this.onKeyUp,this); 
        cc.find("Canvas").on(cc.Node.EventType.MOUSE_DOWN, function (event) {
            console.log('Mouse down');
        }, this);
    }

    start () {
        this.state = GAME_STATE.START;
        this.ShowNodeWithState();
        this.lblScore.string = "Score: 0";
    }

    update (dt) {
        switch(this.state){
            case GAME_STATE.START:{
                break;
            }
            case GAME_STATE.GAME:{
                this.CreateBulletEnemy();
                this.UpdateTimer(dt);
                this.CheckEndGame();
                break;
            }
        }
    }

    private UpdateTimer(dt:number){
        this.timer -= dt;
        this.lblTimer.string = '' + Math.floor(this.timer);
        if(this.timer < 10){
            this.lblTimer.node.color = cc.color(255, 0, 0);
        }
    }

    private CheckEndGame(){
        if(this.player.GetState() == PLAYER_STATE.DIE){
            this.ShowGameEnd(false);
            return;
        }
        if(this.timer <= 0){
            this.ShowGameEnd(false);
            return;
        }
        let i = 0;
        for(; i < this.nodeEnemy.children.length; i++){
            let enemy = this.nodeEnemy.children[i].getComponent(Enemy);
            if(enemy.GetState() != ENEMY_STATE.DIE){
                break;
            }
        }
        if(i >= this.nodeEnemy.children.length - 1){
            this.ShowGameEnd(true);
        }

    }

    /**
     * BeginGame
     */
    public BeginGame() {

    }

    /**
     * EndGame
     */
    private EndGame() {

    }

    /**
     * RestartGame
     */
    public RestartGame() {
        
    }

    private CreateBulletEnemy(){
        this.nodeEnemy.children.forEach(enemy=>{
            let cpm = enemy.getComponent(Enemy);
            if(cpm.GetState() == ENEMY_STATE.FIRE){
                let vec:cc.Vec2 = new cc.Vec2(this.player.node.x - enemy.x, this.player.node.y - enemy.y);
                vec = vec.normalize();
                let bullet = cc.instantiate(this.prefabBulletEnemy);
                bullet.getComponent(BulletEnemy).SetInfo(enemy.x, enemy.y, vec, this.bulletEnemyVeloc);
                this.nodeBulletEnemy.addChild(bullet);
                cpm.SetState(ENEMY_STATE.IDLE);
            }
        })
    }

    public AddScore(){
        this.score += 100;
        this.lblScore.string = "Score: " + this.score;
    }

    public SetHealthNode(){
        let cmp:Player = this.player.getComponent(Player);
        let health = cmp.GetHealth();
        this.nodeHealthArr[0].active = health >= 1;
        this.nodeHealthArr[1].active = health >= 2;
        this.nodeHealthArr[2].active = health >= 3;
    }

    onKeyDown(e:cc.Event.EventKeyboard){
        if(this.state != GAME_STATE.GAME || this.player.GetState() != PLAYER_STATE.IDLE){
            return;
        }
        this.keys.set(e.keyCode,true);
        switch(e.keyCode){
            case cc.macro.KEY.space:
            {
                let bullet = cc.instantiate(this.prefabBullet);
                bullet.getComponent(Bullet).SetBeginPos(this.player.GetPosX(), this.player.GetPosY());
                this.nodeBullet.addChild(bullet);
                break;
            }
            case cc.macro.KEY.left:
            {
                this.player.MoveLeft();
                break;
            }
            case cc.macro.KEY.right:
            {
                this.player.MoveRight();
                break;
            }
            case cc.macro.KEY.up:
            {
                cc.log("up");
                this.player.MoveUp();
                break;
            }
            case cc.macro.KEY.down:
            {
                cc.log("down");
                this.player.MoveDown();
                break;
            }
            case cc.macro.KEY.escape:
            {
                break;
            }
        }
    }

    onKeyUp(e:cc.Event.EventKeyboard){
        this.keys.delete(e.keyCode);
    }

    private ShowNodeWithState(){
        this.nodeStart.active = false;
        this.nodeLevel.active = false;
        this.nodeLevelInfo.active = false;
        this.nodeGame.active = false;
        this.nodeEnd.active = false;
        switch(this.state){
            case GAME_STATE.START:
            {
                this.nodeStart.active = true;
                break;
            }
            case GAME_STATE.LEVEL:
            {
                this.nodeLevel.active = true;
                break;
            }
            case GAME_STATE.LEVEL_INFO:
            {
                this.nodeLevelInfo.active = true;
                break;
            }
            case GAME_STATE.GAME:
            {
                this.nodeGame.active = true;
                break;
            }
            case GAME_STATE.END:
            {
                this.nodeEnd.active = true;
                break;
            }
        }
    }

    private ShowInfoWithLevel(){
        this.infoLv1.active = false;
        this.infoLv2.active = false;
        this.infoLv3.active = false;
        switch(this.level){
            case 1:
            {
                this.infoLv1.active = true;
                break;
            }
            case 2:
            {
                this.infoLv2.active = true;
                break;
            }
            case 3:
            {
                this.infoLv3.active = true;
                break;
            }
        }
    }

    private SetUpGameWithLevel(){
        this.score = 0;
        this.player.SetInfo(this);
        this.lblTimer.node.color = cc.color(255, 255, 255);
        let enemy_health_max = 0;
        let enemy_veloc = 0;
        let enemy_time_fire = 0;
        let enemy_percent_fire = 0;
        this.nodeBullet.children.forEach(element => {
            element.destroy();
        });
        this.nodeBulletEnemy.children.forEach(element => {
            element.destroy();
        })
        switch(this.level){
            case 1:
            {
                this.timer = GameManager.Defines.TIMER_LV_1;
                this.bulletEnemyVeloc = GameManager.Defines.BULLET_VELOC_LV_1;
                enemy_health_max = GameManager.Defines.ENEMY_MAX_HEALTH_LV_1;
                enemy_veloc = GameManager.Defines.ENEMY_VELOC_LV_1;
                enemy_time_fire = GameManager.Defines.ENEMY_TIME_FIRE_LV_1;
                enemy_percent_fire = GameManager.Defines.ENEMY_PERCENT_FIRE_LV_1;
                break;
            }
            case 2:
            {
                this.timer = GameManager.Defines.TIMER_LV_2;
                this.bulletEnemyVeloc = GameManager.Defines.BULLET_VELOC_LV_2;
                enemy_health_max = GameManager.Defines.ENEMY_MAX_HEALTH_LV_2;
                enemy_veloc = GameManager.Defines.ENEMY_VELOC_LV_2;
                enemy_time_fire = GameManager.Defines.ENEMY_TIME_FIRE_LV_2;
                enemy_percent_fire = GameManager.Defines.ENEMY_PERCENT_FIRE_LV_2;
                break;
            }
            case 3:
            {
                this.timer = GameManager.Defines.TIMER_LV_3;
                this.bulletEnemyVeloc = GameManager.Defines.BULLET_VELOC_LV_3;
                enemy_health_max = GameManager.Defines.ENEMY_MAX_HEALTH_LV_3;
                enemy_veloc = GameManager.Defines.ENEMY_VELOC_LV_3;
                enemy_time_fire = GameManager.Defines.ENEMY_TIME_FIRE_LV_3;
                enemy_percent_fire = GameManager.Defines.ENEMY_PERCENT_FIRE_LV_3;
                break;
            }
        }

        this.nodeEnemy.children.forEach(enemy=>{
            let cpm = enemy.getComponent(Enemy);
            let health = Math.floor(Math.random() * enemy_health_max) + 1;
            let time_fire = Math.floor(Math.random() * (enemy_time_fire - GameManager.Defines.ENEMY_TIME_FIRE_BASE)) + GameManager.Defines.ENEMY_TIME_FIRE_BASE;
            cpm.SetInfo(enemy_veloc, health, time_fire, enemy_percent_fire, this);
        });
        
    }

    private ShowGameEnd(is_win:boolean){
        this.nodeGameLose.active = false;
        this.nodeGameWin.active = false;
        this.state = GAME_STATE.END;
        if(is_win){
            this.nodeGameWin.active = true;
        }
        else
        {
            this.nodeGameLose.active = true;
        }
        this.lblScoreEnd.string = 'Score: ' + this.score.toString();
        this.ShowNodeWithState();
    }

    private OnTouchStart(){
        this.state = GAME_STATE.LEVEL;
        this.ShowNodeWithState();
    }

    private OnTouchEasy(){
        this.state = GAME_STATE.LEVEL_INFO;
        this.ShowNodeWithState();
        this.level = 1;
        this.ShowInfoWithLevel();
    }

    private OnTouchNormal(){
        this.state = GAME_STATE.LEVEL_INFO;
        this.ShowNodeWithState();
        this.level = 2;
        this.ShowInfoWithLevel();
    }

    private OnTouchHard(){
        this.state = GAME_STATE.LEVEL_INFO;
        this.ShowNodeWithState();
        this.level = 3;
        this.ShowInfoWithLevel();
    }

    private OnTouchBack(){
        this.state = GAME_STATE.LEVEL;
        this.ShowNodeWithState();
    }

    private OnTouchPlay(){
        this.state = GAME_STATE.GAME;
        this.ShowNodeWithState();
        this.SetUpGameWithLevel();
    }


}
