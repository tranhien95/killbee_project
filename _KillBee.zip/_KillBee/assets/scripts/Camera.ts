import Player from "./Player";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Camera extends cc.Component {

    onLoad () {
    }

    start () {
    }

    update (dt) {
    }
}
