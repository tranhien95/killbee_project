import GameManager from "./GameManager";

const {ccclass, property} = cc._decorator;

@ccclass
export default class ScrollBG extends cc.Component {

    @property
    private screenHeight: number = 0;

    private childCount: number = 0;
    private scaleY: number = 0;
    
    start () {
        this.scaleY = this.screenHeight / this.node.children[0].getBoundingBox().height;
        for(let i = 0; i < this.node.childrenCount; i++)
        {
            this.node.children[i].scaleX = this.scaleY;
            this.node.children[i].y = this.screenHeight * i;
        }
        this.childCount = this.node.childrenCount;
    }

    update (dt) {
        for(let i = 0; i < this.childCount; i++){
            let element = this.node.children[i];
            element.y -= GameManager.Defines.BACKGROUND_SCROLLING_VELOC * dt;
            if(element.y < -this.screenHeight){
                let top_index = this.CalculateTopIndex(i, this.childCount);
                element.y =  this.screenHeight + this.node.children[top_index].y;
            }
        }
    }

    private CalculateTopIndex(cur_index:number, count:number):number{
        if(cur_index == (count - 1)){
            return 0;
        }
        return (cur_index + 1)
    }
}
