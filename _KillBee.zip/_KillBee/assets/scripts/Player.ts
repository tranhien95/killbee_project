import { PLAYER_STATE, COLLIDER_TAG } from "./Enum";
import { ObjectBase } from "./ObjectBase";
import GameManager from "./GameManager";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Player extends ObjectBase {
    @property(cc.Animation)
    private anim: cc.Animation = null;
    @property(cc.Sprite)
    private spriteMain: cc.Sprite = null;
    @property(cc.SpriteFrame)
    private spriteFrame:cc.SpriteFrame = null;

    // rigid
    private rigid : cc.RigidBody;
    private state: PLAYER_STATE;
    private gm:GameManager;

    private collisionManager;

    keys : Map<number,boolean> = new Map();

    onLoad () {
        
        let physicsManager = cc.director.getPhysicsManager();
        physicsManager.enabled = true;

        this.rigid = this.node.getComponent(cc.RigidBody);
        this.collisionManager = cc.director.getCollisionManager();
        this.collisionManager.enabled = true;
        this.collisionManager.enabledDebugDraw = true;
    }

    start () {

    }

    public SetInfo(gm:GameManager){
        this.node.active = true;
        this.spriteMain.spriteFrame = this.spriteFrame;
        this.gm = gm;
        this.state = PLAYER_STATE.IDLE;
        this.node.x = GameManager.Defines.PLAYER_BEGIN_POS_X;
        this.node.y = GameManager.Defines.PLAYER_BEGIN_POS_Y;
        this.health = GameManager.Defines.PLAYER_HEALTH;
    }

    update (dt) {
        switch(this.state){
            case PLAYER_STATE.NONE:
            {
                break;
            }
            case PLAYER_STATE.IDLE:
            {
                break;
            }
            case PLAYER_STATE.BURST:
            {
                break;
            }
            case PLAYER_STATE.DIE:
            {
                break;
            }
        }
    }

    private SetBurst(){
        this.state = PLAYER_STATE.BURST;
        this.anim.play(this.anim.getClips()[0].name);
        this.anim.getAnimationState(this.anim.getClips()[0].name).wrapMode = cc.WrapMode.Normal;
        let t = this;
        this.anim.on('finished', (event) => {
            if(this.health == 0){
                t.state = PLAYER_STATE.DIE;
                t.anim.stop();
                t.node.active = false;
            }
            else
            {
                t.spriteMain.spriteFrame = this.spriteFrame;
                t.state = PLAYER_STATE.IDLE;
                this.node.x = GameManager.Defines.PLAYER_BEGIN_POS_X;
                this.node.y = GameManager.Defines.PLAYER_BEGIN_POS_Y;
            }
        });
    }

    onCollisionEnter(other, sefl)
    {
        let num_tag = +other.getComponent(cc.BoxCollider).tag;
        if((num_tag == COLLIDER_TAG.ENEMY || num_tag == COLLIDER_TAG.BULLET_ENEMY) && (this.state == PLAYER_STATE.IDLE))
        {
            this.health--;
            this.gm.SetHealthNode();
            this.SetBurst();
        }
    }

    public MoveLeft(){
        this.node.x -= GameManager.Defines.PLAYER_DISTANCE_MOVE;
        this.AlwaysOnScreen();
    }

    public MoveRight(){
        this.node.x += GameManager.Defines.PLAYER_DISTANCE_MOVE;
        this.AlwaysOnScreen();
    }

    public MoveUp(){
        this.node.y += GameManager.Defines.PLAYER_DISTANCE_MOVE;
        this.AlwaysOnScreen();
    }

    public MoveDown(){
        this.node.y -= GameManager.Defines.PLAYER_DISTANCE_MOVE;
        this.AlwaysOnScreen();
    }

    private AlwaysOnScreen(){
        let width_2 = this.node.width / 2;
        let height_2 = this.node.height / 2;

        if(this.node.x + width_2 > GameManager.Defines.SCREEN_WIDTH / 2){
            this.node.x = GameManager.Defines.SCREEN_WIDTH / 2 - width_2;
        }

        if(this.node.x - width_2 < - GameManager.Defines.SCREEN_WIDTH / 2){
            this.node.x = width_2 - GameManager.Defines.SCREEN_WIDTH / 2;
        }

        if(this.node.y + height_2 > GameManager.Defines.SCREEN_HEIGHT / 2){
            this.node.y = GameManager.Defines.SCREEN_HEIGHT / 2 - height_2;
        }

        if(this.node.y - height_2 < - GameManager.Defines.SCREEN_HEIGHT / 2){
            this.node.y = height_2 - GameManager.Defines.SCREEN_HEIGHT / 2;
        }
    }

    public GetPosX():number{
        return this.node.x;
    }

    public GetPosY():number{
        return this.node.y;
    }

    public GetState():PLAYER_STATE{
        return this.state;
    }
}
