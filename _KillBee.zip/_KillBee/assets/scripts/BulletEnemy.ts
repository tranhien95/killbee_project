import { ObjectBase } from "./ObjectBase";
import GameManager from "./GameManager";
import MyUtils from "./MyUtils";

const {ccclass, property} = cc._decorator;

@ccclass
export default class BulletEnemy extends ObjectBase {

    private vec:cc.Vec2;
    
    public SetInfo(x: number, y: number, vec: cc.Vec2, v: number){
        this.node.x = x;
        this.node.y = y;
        this.veloc = v;
        this.vec = vec;
    }

    update(dt){
        this.node.x += this.vec.x * this.veloc * dt;
        this.node.y += this.vec.y * this.veloc * dt;
        MyUtils.CheckOutScreenDestroy(this.node);
    }
}