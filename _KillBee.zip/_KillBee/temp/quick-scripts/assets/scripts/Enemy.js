(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Enemy.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0558e2u4odOdrIwPU32cTy/', 'Enemy', __filename);
// scripts/Enemy.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ObjectBase_1 = require("./ObjectBase");
var GameManager_1 = require("./GameManager");
var Enum_1 = require("./Enum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Enemy = /** @class */ (function (_super) {
    __extends(Enemy, _super);
    function Enemy() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.anim = null;
        _this.nodeHealthArr = [];
        _this.bFire = false;
        _this.timeFireDefine = 0;
        _this.percentFireDefine = 0;
        _this.timeFire = 0;
        _this.timeBurst = 0;
        _this.xBegin = 0;
        _this.itemtype = 0;
        _this.state = Enum_1.ENEMY_STATE.NONE;
        _this.gm = null;
        return _this;
    }
    Enemy.prototype.SetInfo = function (v, h, time_fire, percent_fire, gm) {
        this.node.active = true;
        this.node.x = this.xBegin;
        this.state = Enum_1.ENEMY_STATE.IDLE;
        this.veloc = v;
        this.health = h;
        if (this.health > GameManager_1.default.Defines.ENEMY_MAX_HEALTH) {
            this.health = GameManager_1.default.Defines.ENEMY_MAX_HEALTH;
        }
        this.timeFireDefine = time_fire;
        this.percentFireDefine = percent_fire;
        this.state = Enum_1.ENEMY_STATE.IDLE;
        this.SetHealthNode();
        this.anim.play(this.anim.getClips()[0].name);
        this.anim.getAnimationState(this.anim.getClips()[0].name).wrapMode = cc.WrapMode.Loop;
        this.gm = gm;
        this.timeFire = 0;
    };
    Enemy.prototype.onLoad = function () {
        this.xBegin = this.node.x;
    };
    Enemy.prototype.start = function () {
    };
    Enemy.prototype.update = function (dt) {
        switch (this.state) {
            case Enum_1.ENEMY_STATE.IDLE:
            case Enum_1.ENEMY_STATE.FIRE:
                {
                    if (this.node.x > this.xBegin + GameManager_1.default.Defines.ENEMY_DISTANCE_MOVE) {
                        this.veloc = -Math.abs(this.veloc);
                        this.node.x += this.veloc * dt;
                    }
                    else if (this.node.x < this.xBegin - GameManager_1.default.Defines.ENEMY_DISTANCE_MOVE) {
                        this.veloc = Math.abs(this.veloc);
                        this.node.x += this.veloc * dt;
                    }
                    else {
                        this.node.x += this.veloc * dt;
                    }
                    this.timeFire += dt;
                    if (this.timeFire >= this.timeFireDefine) {
                        var rand = Math.floor(Math.random() * 100);
                        if (rand <= this.percentFireDefine) {
                            this.state = Enum_1.ENEMY_STATE.FIRE;
                        }
                        this.timeFire = 0;
                    }
                    break;
                }
            case Enum_1.ENEMY_STATE.BURST:
                {
                    break;
                }
            case Enum_1.ENEMY_STATE.DIE:
                {
                    break;
                }
        }
    };
    Enemy.prototype.SetState = function (state) {
        this.state = state;
    };
    Enemy.prototype.onCollisionEnter = function (other, sefl) {
        var num_tag = +other.getComponent(cc.BoxCollider).tag;
        if ((num_tag == Enum_1.COLLIDER_TAG.BULLET || num_tag == Enum_1.COLLIDER_TAG.PLAYER) && (this.state == Enum_1.ENEMY_STATE.IDLE || this.state == Enum_1.ENEMY_STATE.FIRE)) {
            if (num_tag != Enum_1.COLLIDER_TAG.PLAYER) {
                other.node.destroy();
            }
            this.health--;
            this.SetHealthNode();
            this.gm.AddScore();
            if (this.health == 0) {
                this.SetBurst();
            }
        }
    };
    Enemy.prototype.SetBurst = function () {
        this.state = Enum_1.ENEMY_STATE.BURST;
        this.anim.play(this.anim.getClips()[1].name);
        this.anim.getAnimationState(this.anim.getClips()[1].name).wrapMode = cc.WrapMode.Normal;
        var t = this;
        this.anim.on('finished', function (event) {
            t.node.active = false;
            t.state = Enum_1.ENEMY_STATE.DIE;
        });
    };
    Enemy.prototype.SetHealthNode = function () {
        this.nodeHealthArr[0].active = this.health >= 1;
        this.nodeHealthArr[1].active = this.health >= 2;
        this.nodeHealthArr[2].active = this.health >= 3;
    };
    Enemy.prototype.GetState = function () {
        return this.state;
    };
    __decorate([
        property(cc.Animation)
    ], Enemy.prototype, "anim", void 0);
    __decorate([
        property([cc.Node])
    ], Enemy.prototype, "nodeHealthArr", void 0);
    Enemy = __decorate([
        ccclass
    ], Enemy);
    return Enemy;
}(ObjectBase_1.ObjectBase));
exports.default = Enemy;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Enemy.js.map
        