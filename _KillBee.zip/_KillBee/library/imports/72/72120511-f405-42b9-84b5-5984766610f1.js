"use strict";
cc._RF.push(module, '72120UR9AVCuYS1WYR2ZhDx', 'Score');
// scripts/Score.ts

// Learn TypeScript:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.sprs = [];
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    NewClass.prototype.start = function () {
        var num1 = cc.instantiate(this.num);
        this.node.addChild(num1);
    };
    // update (dt) {}
    NewClass.prototype.SetScore = function (score) {
        this.score = score;
        var count = this.CountNumberScore(score);
        if (count == this.node.childrenCount) {
            this.SetScoreSprite(score);
        }
        else {
            for (var i = 0; i < this.node.childrenCount; i++) {
                this.node.children[i].x += this.node.children[0].getBoundingBox().width / 2;
            }
            var num1 = cc.instantiate(this.num);
            this.node.addChild(num1);
            num1.position = new cc.Vec2(this.node.children[0].position.x
                - this.node.children[0].getBoundingBox().width * (this.node.childrenCount - 1), 0);
            this.SetScoreSprite(score);
        }
    };
    NewClass.prototype.CountNumberScore = function (score) {
        var count = 0;
        while (score >= 1) {
            score = score / 10;
            count++;
        }
        return count;
    };
    NewClass.prototype.SetScoreSprite = function (score) {
        var index = 0;
        while (score >= 1) {
            var num = score % 10;
            score = Math.floor(score / 10);
            this.node.children[index].getComponent(cc.Sprite).spriteFrame = this.sprs[num];
            index++;
        }
    };
    NewClass.prototype.Reset = function () {
        this.node.removeAllChildren();
        var num1 = cc.instantiate(this.num);
        this.node.addChild(num1);
    };
    __decorate([
        property(cc.Prefab)
    ], NewClass.prototype, "num", void 0);
    __decorate([
        property([cc.SpriteFrame])
    ], NewClass.prototype, "sprs", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();