import { ObjectBase } from "./ObjectBase";
import GameManager from "./GameManager";
import { ENEMY_STATE, COLLIDER_TAG } from "./Enum";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Enemy extends ObjectBase {
    
    @property(cc.Animation)
    anim: cc.Animation = null;
    @property([cc.Node])
    nodeHealthArr: cc.Node[] = [];

    private bFire: boolean = false;
    private timeFireDefine: number = 0;
    private percentFireDefine: number = 0;
    private timeFire: number = 0;
    private timeBurst: number = 0;
    private xBegin: number = 0;
    private itemtype: number = 0;
    private state: ENEMY_STATE = ENEMY_STATE.NONE;
    private gm:GameManager = null

    public SetInfo(v: number, h:number, time_fire:number, percent_fire: number, gm:GameManager){
        this.node.active = true;
        this.node.x = this.xBegin;
        this.state = ENEMY_STATE.IDLE;
        this.veloc = v;
        this.health = h;
        if(this.health > GameManager.Defines.ENEMY_MAX_HEALTH){
            this.health = GameManager.Defines.ENEMY_MAX_HEALTH;
        }
        this.timeFireDefine = time_fire;
        this.percentFireDefine = percent_fire;
        this.state = ENEMY_STATE.IDLE;
        this.SetHealthNode();
        this.anim.play(this.anim.getClips()[0].name);
        this.anim.getAnimationState(this.anim.getClips()[0].name).wrapMode = cc.WrapMode.Loop;
        this.gm = gm;
        this.timeFire = 0;
    }

    onLoad(){
        this.xBegin = this.node.x;
    }

    start(){
        
    }

    update(dt){
        switch(this.state){
            case ENEMY_STATE.IDLE:
            case ENEMY_STATE.FIRE:
            {
                if(this.node.x > this.xBegin + GameManager.Defines.ENEMY_DISTANCE_MOVE){
                    this.veloc = - Math.abs(this.veloc);
                    this.node.x += this.veloc * dt;
                }
                else
                if(this.node.x < this.xBegin - GameManager.Defines.ENEMY_DISTANCE_MOVE){
                    this.veloc = Math.abs(this.veloc);
                    this.node.x += this.veloc * dt;
                }
                else
                {
                    this.node.x += this.veloc * dt;
                }
                this.timeFire += dt;
                if(this.timeFire >= this.timeFireDefine){
                    let rand = Math.floor(Math.random() * 100);
                    if(rand <= this.percentFireDefine){
                        this.state = ENEMY_STATE.FIRE;
                    }
                    this.timeFire = 0;
                }
                break;
            }
            case ENEMY_STATE.BURST:
            {
                
                break;
            }
            case ENEMY_STATE.DIE:
            {
                    
                break;
            }
        }
    }

    public SetState(state: ENEMY_STATE){
        this.state = state;
    }

    onCollisionEnter(other, sefl)
    {
        let num_tag = +other.getComponent(cc.BoxCollider).tag;
        if((num_tag == COLLIDER_TAG.BULLET || num_tag == COLLIDER_TAG.PLAYER) && (this.state == ENEMY_STATE.IDLE || this.state == ENEMY_STATE.FIRE))
        {
            if(num_tag != COLLIDER_TAG.PLAYER){
                other.node.destroy();
            }
            this.health--;
            this.SetHealthNode();
            this.gm.AddScore();
            if(this.health == 0){
                this.SetBurst();
            }
        }
    }

    private SetBurst(){
        this.state = ENEMY_STATE.BURST;
        this.anim.play(this.anim.getClips()[1].name);
        this.anim.getAnimationState(this.anim.getClips()[1].name).wrapMode = cc.WrapMode.Normal;
        let t = this;
        this.anim.on('finished', (event) => {
            t.node.active = false;
            t.state = ENEMY_STATE.DIE;
        });
    }

    private SetHealthNode(){
        this.nodeHealthArr[0].active = this.health >= 1;
        this.nodeHealthArr[1].active = this.health >= 2;
        this.nodeHealthArr[2].active = this.health >= 3;
    }

    public GetState():ENEMY_STATE{
        return this.state;
    }


}