(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Bullet.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '6360dZrLS9M2KEUlSvK1klh', 'Bullet', __filename);
// scripts/Bullet.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ObjectBase_1 = require("./ObjectBase");
var GameManager_1 = require("./GameManager");
var MyUtils_1 = require("./MyUtils");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Bullet = /** @class */ (function (_super) {
    __extends(Bullet, _super);
    function Bullet() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Bullet.prototype.SetBeginPos = function (x, y) {
        this.node.x = x;
        this.node.y = y;
    };
    Bullet.prototype.update = function (dt) {
        this.node.y += GameManager_1.default.Defines.PLAYER_BULLET_VELOC * dt;
        MyUtils_1.default.CheckOutScreenDestroy(this.node);
    };
    Bullet = __decorate([
        ccclass
    ], Bullet);
    return Bullet;
}(ObjectBase_1.ObjectBase));
exports.default = Bullet;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Bullet.js.map
        