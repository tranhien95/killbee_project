"use strict";
cc._RF.push(module, 'd922eKnsUpCtbw15YgRyZ1O', 'GlobalDefines');
// scripts/GlobalDefines.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GlobalDefines = /** @class */ (function () {
    function GlobalDefines() {
        this.PLAYER_HEALTH = 3;
        this.PLAYER_BULLET_VELOC = 200;
        this.PLAYER_BEGIN_POS_X = 0;
        this.PLAYER_BEGIN_POS_Y = -217;
        this.BACKGROUND_SCROLLING_VELOC = 300;
        this.PLAYER_DISTANCE_MOVE = 20;
        this.SCREEN_WIDTH = 512;
        this.SCREEN_HEIGHT = 512;
        this.ENEMY_DISTANCE_MOVE = 100;
        this.ENEMY_MAX_HEALTH = 3;
        this.ENEMY_BULLET_VELOC = 200;
        this.ENEMY_TIME_FIRE_LV_1 = 10;
        this.ENEMY_TIME_FIRE_LV_2 = 7;
        this.ENEMY_TIME_FIRE_LV_3 = 5;
        this.ENEMY_TIME_FIRE_BASE = 3;
        this.ENEMY_PERCENT_FIRE_LV_1 = 15;
        this.ENEMY_PERCENT_FIRE_LV_2 = 20;
        this.ENEMY_PERCENT_FIRE_LV_3 = 25;
        this.ENEMY_MAX_HEALTH_LV_1 = 1;
        this.ENEMY_MAX_HEALTH_LV_2 = 2;
        this.ENEMY_MAX_HEALTH_LV_3 = 3;
        this.ENEMY_VELOC_LV_1 = 80;
        this.ENEMY_VELOC_LV_2 = 120;
        this.ENEMY_VELOC_LV_3 = 160;
        this.SCREEN_MAX_X = 300;
        this.SCREEN_MIN_X = -300;
        this.SCREEN_MAX_Y = 300;
        this.SCREEN_MIN_Y = -300;
        this.TIMER_LV_1 = 60;
        this.TIMER_LV_2 = 50;
        this.TIMER_LV_3 = 40;
        this.BULLET_VELOC_LV_1 = 50;
        this.BULLET_VELOC_LV_2 = 60;
        this.BULLET_VELOC_LV_3 = 70;
    }
    GlobalDefines = __decorate([
        ccclass
    ], GlobalDefines);
    return GlobalDefines;
}());
exports.default = GlobalDefines;

cc._RF.pop();