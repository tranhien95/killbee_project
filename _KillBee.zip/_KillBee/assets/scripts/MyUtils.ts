import GameManager from "./GameManager";

export default class MyUtils {
    static CheckOutScreenDestroy(node:cc.Node){
        if(node.x < GameManager.Defines.SCREEN_MIN_X
            || node.x > GameManager.Defines.SCREEN_MAX_X
            || node.y > GameManager.Defines.SCREEN_MAX_Y
            || node.y < GameManager.Defines.SCREEN_MIN_Y){
                cc.log("destroy");
                node.destroy();
            }
    }
}