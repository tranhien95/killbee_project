(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/MyUtils.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '7d66bybSjFAc60vSj1kM4BS', 'MyUtils', __filename);
// scripts/MyUtils.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameManager_1 = require("./GameManager");
var MyUtils = /** @class */ (function () {
    function MyUtils() {
    }
    MyUtils.CheckOutScreenDestroy = function (node) {
        if (node.x < GameManager_1.default.Defines.SCREEN_MIN_X
            || node.x > GameManager_1.default.Defines.SCREEN_MAX_X
            || node.y > GameManager_1.default.Defines.SCREEN_MAX_Y
            || node.y < GameManager_1.default.Defines.SCREEN_MIN_Y) {
            cc.log("destroy");
            node.destroy();
        }
    };
    return MyUtils;
}());
exports.default = MyUtils;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MyUtils.js.map
        