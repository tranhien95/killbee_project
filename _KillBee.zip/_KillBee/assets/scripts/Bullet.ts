import { ObjectBase } from "./ObjectBase";
import GameManager from "./GameManager";
import MyUtils from "./MyUtils";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Bullet extends ObjectBase {
    

    public SetBeginPos(x:number, y:number){
        this.node.x = x;
        this.node.y = y;
    }

    update(dt){
        this.node.y += GameManager.Defines.PLAYER_BULLET_VELOC * dt;
        MyUtils.CheckOutScreenDestroy(this.node);
    }
}