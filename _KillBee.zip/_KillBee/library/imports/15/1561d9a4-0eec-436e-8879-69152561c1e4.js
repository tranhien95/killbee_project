"use strict";
cc._RF.push(module, '1561dmkDuxDboh5aRUlYcHk', 'Camera');
// scripts/Camera.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Camera = /** @class */ (function (_super) {
    __extends(Camera, _super);
    function Camera() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Camera.prototype.onLoad = function () {
    };
    Camera.prototype.start = function () {
    };
    Camera.prototype.update = function (dt) {
    };
    Camera = __decorate([
        ccclass
    ], Camera);
    return Camera;
}(cc.Component));
exports.default = Camera;

cc._RF.pop();