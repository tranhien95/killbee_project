"use strict";
cc._RF.push(module, '67bd3sPNt1GhJfl0h0mv5aJ', 'GameManager');
// scripts/GameManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Player_1 = require("./Player");
var GlobalDefines_1 = require("./GlobalDefines");
var Bullet_1 = require("./Bullet");
var Enum_1 = require("./Enum");
var Enemy_1 = require("./Enemy");
var BulletEnemy_1 = require("./BulletEnemy");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameManager = /** @class */ (function (_super) {
    __extends(GameManager, _super);
    function GameManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.player = null;
        _this.nodeEnemy = null;
        _this.nodeBullet = null;
        _this.nodeBulletEnemy = null;
        _this.prefabEnemy = null;
        _this.prefabBullet = null;
        _this.prefabBulletEnemy = null;
        _this.lblScore = null;
        _this.nodeHealthArr = [];
        _this.nodeStart = null;
        _this.nodeLevel = null;
        _this.nodeLevelInfo = null;
        _this.nodeGame = null;
        _this.nodeEnd = null;
        _this.infoLv1 = null;
        _this.infoLv2 = null;
        _this.infoLv3 = null;
        _this.lblTimer = null;
        _this.nodeGameWin = null;
        _this.nodeGameLose = null;
        _this.lblScoreEnd = null;
        _this.keys = new Map();
        _this.state = Enum_1.GAME_STATE.START;
        _this.score = 0;
        _this.level = 0;
        _this.timer = 0;
        _this.bulletEnemyVeloc = 0;
        return _this;
    }
    GameManager_1 = GameManager;
    // LIFE-CYCLE CALLBACKS:
    GameManager.prototype.onLoad = function () {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
        cc.find("Canvas").on(cc.Node.EventType.MOUSE_DOWN, function (event) {
            console.log('Mouse down');
        }, this);
    };
    GameManager.prototype.start = function () {
        this.state = Enum_1.GAME_STATE.START;
        this.ShowNodeWithState();
        this.lblScore.string = "Score: 0";
    };
    GameManager.prototype.update = function (dt) {
        switch (this.state) {
            case Enum_1.GAME_STATE.START: {
                break;
            }
            case Enum_1.GAME_STATE.GAME: {
                this.CreateBulletEnemy();
                this.UpdateTimer(dt);
                this.CheckEndGame();
                break;
            }
        }
    };
    GameManager.prototype.UpdateTimer = function (dt) {
        this.timer -= dt;
        this.lblTimer.string = '' + Math.floor(this.timer);
        if (this.timer < 10) {
            this.lblTimer.node.color = cc.color(255, 0, 0);
        }
    };
    GameManager.prototype.CheckEndGame = function () {
        if (this.player.GetState() == Enum_1.PLAYER_STATE.DIE) {
            this.ShowGameEnd(false);
            return;
        }
        if (this.timer <= 0) {
            this.ShowGameEnd(false);
            return;
        }
        var i = 0;
        for (; i < this.nodeEnemy.children.length; i++) {
            var enemy = this.nodeEnemy.children[i].getComponent(Enemy_1.default);
            if (enemy.GetState() != Enum_1.ENEMY_STATE.DIE) {
                break;
            }
        }
        if (i >= this.nodeEnemy.children.length - 1) {
            this.ShowGameEnd(true);
        }
    };
    /**
     * BeginGame
     */
    GameManager.prototype.BeginGame = function () {
    };
    /**
     * EndGame
     */
    GameManager.prototype.EndGame = function () {
    };
    /**
     * RestartGame
     */
    GameManager.prototype.RestartGame = function () {
    };
    GameManager.prototype.CreateBulletEnemy = function () {
        var _this = this;
        this.nodeEnemy.children.forEach(function (enemy) {
            var cpm = enemy.getComponent(Enemy_1.default);
            if (cpm.GetState() == Enum_1.ENEMY_STATE.FIRE) {
                var vec = new cc.Vec2(_this.player.node.x - enemy.x, _this.player.node.y - enemy.y);
                vec = vec.normalize();
                var bullet = cc.instantiate(_this.prefabBulletEnemy);
                bullet.getComponent(BulletEnemy_1.default).SetInfo(enemy.x, enemy.y, vec, _this.bulletEnemyVeloc);
                _this.nodeBulletEnemy.addChild(bullet);
                cpm.SetState(Enum_1.ENEMY_STATE.IDLE);
            }
        });
    };
    GameManager.prototype.AddScore = function () {
        this.score += 100;
        this.lblScore.string = "Score: " + this.score;
    };
    GameManager.prototype.SetHealthNode = function () {
        var cmp = this.player.getComponent(Player_1.default);
        var health = cmp.GetHealth();
        this.nodeHealthArr[0].active = health >= 1;
        this.nodeHealthArr[1].active = health >= 2;
        this.nodeHealthArr[2].active = health >= 3;
    };
    GameManager.prototype.onKeyDown = function (e) {
        if (this.state != Enum_1.GAME_STATE.GAME || this.player.GetState() != Enum_1.PLAYER_STATE.IDLE) {
            return;
        }
        this.keys.set(e.keyCode, true);
        switch (e.keyCode) {
            case cc.macro.KEY.space:
                {
                    var bullet = cc.instantiate(this.prefabBullet);
                    bullet.getComponent(Bullet_1.default).SetBeginPos(this.player.GetPosX(), this.player.GetPosY());
                    this.nodeBullet.addChild(bullet);
                    break;
                }
            case cc.macro.KEY.left:
                {
                    this.player.MoveLeft();
                    break;
                }
            case cc.macro.KEY.right:
                {
                    this.player.MoveRight();
                    break;
                }
            case cc.macro.KEY.up:
                {
                    cc.log("up");
                    this.player.MoveUp();
                    break;
                }
            case cc.macro.KEY.down:
                {
                    cc.log("down");
                    this.player.MoveDown();
                    break;
                }
            case cc.macro.KEY.escape:
                {
                    break;
                }
        }
    };
    GameManager.prototype.onKeyUp = function (e) {
        this.keys.delete(e.keyCode);
    };
    GameManager.prototype.ShowNodeWithState = function () {
        this.nodeStart.active = false;
        this.nodeLevel.active = false;
        this.nodeLevelInfo.active = false;
        this.nodeGame.active = false;
        this.nodeEnd.active = false;
        switch (this.state) {
            case Enum_1.GAME_STATE.START:
                {
                    this.nodeStart.active = true;
                    break;
                }
            case Enum_1.GAME_STATE.LEVEL:
                {
                    this.nodeLevel.active = true;
                    break;
                }
            case Enum_1.GAME_STATE.LEVEL_INFO:
                {
                    this.nodeLevelInfo.active = true;
                    break;
                }
            case Enum_1.GAME_STATE.GAME:
                {
                    this.nodeGame.active = true;
                    break;
                }
            case Enum_1.GAME_STATE.END:
                {
                    this.nodeEnd.active = true;
                    break;
                }
        }
    };
    GameManager.prototype.ShowInfoWithLevel = function () {
        this.infoLv1.active = false;
        this.infoLv2.active = false;
        this.infoLv3.active = false;
        switch (this.level) {
            case 1:
                {
                    this.infoLv1.active = true;
                    break;
                }
            case 2:
                {
                    this.infoLv2.active = true;
                    break;
                }
            case 3:
                {
                    this.infoLv3.active = true;
                    break;
                }
        }
    };
    GameManager.prototype.SetUpGameWithLevel = function () {
        var _this = this;
        this.score = 0;
        this.player.SetInfo(this);
        this.lblTimer.node.color = cc.color(255, 255, 255);
        var enemy_health_max = 0;
        var enemy_veloc = 0;
        var enemy_time_fire = 0;
        var enemy_percent_fire = 0;
        this.nodeBullet.children.forEach(function (element) {
            element.destroy();
        });
        this.nodeBulletEnemy.children.forEach(function (element) {
            element.destroy();
        });
        switch (this.level) {
            case 1:
                {
                    this.timer = GameManager_1.Defines.TIMER_LV_1;
                    this.bulletEnemyVeloc = GameManager_1.Defines.BULLET_VELOC_LV_1;
                    enemy_health_max = GameManager_1.Defines.ENEMY_MAX_HEALTH_LV_1;
                    enemy_veloc = GameManager_1.Defines.ENEMY_VELOC_LV_1;
                    enemy_time_fire = GameManager_1.Defines.ENEMY_TIME_FIRE_LV_1;
                    enemy_percent_fire = GameManager_1.Defines.ENEMY_PERCENT_FIRE_LV_1;
                    break;
                }
            case 2:
                {
                    this.timer = GameManager_1.Defines.TIMER_LV_2;
                    this.bulletEnemyVeloc = GameManager_1.Defines.BULLET_VELOC_LV_2;
                    enemy_health_max = GameManager_1.Defines.ENEMY_MAX_HEALTH_LV_2;
                    enemy_veloc = GameManager_1.Defines.ENEMY_VELOC_LV_2;
                    enemy_time_fire = GameManager_1.Defines.ENEMY_TIME_FIRE_LV_2;
                    enemy_percent_fire = GameManager_1.Defines.ENEMY_PERCENT_FIRE_LV_2;
                    break;
                }
            case 3:
                {
                    this.timer = GameManager_1.Defines.TIMER_LV_3;
                    this.bulletEnemyVeloc = GameManager_1.Defines.BULLET_VELOC_LV_3;
                    enemy_health_max = GameManager_1.Defines.ENEMY_MAX_HEALTH_LV_3;
                    enemy_veloc = GameManager_1.Defines.ENEMY_VELOC_LV_3;
                    enemy_time_fire = GameManager_1.Defines.ENEMY_TIME_FIRE_LV_3;
                    enemy_percent_fire = GameManager_1.Defines.ENEMY_PERCENT_FIRE_LV_3;
                    break;
                }
        }
        this.nodeEnemy.children.forEach(function (enemy) {
            var cpm = enemy.getComponent(Enemy_1.default);
            var health = Math.floor(Math.random() * enemy_health_max) + 1;
            var time_fire = Math.floor(Math.random() * (enemy_time_fire - GameManager_1.Defines.ENEMY_TIME_FIRE_BASE)) + GameManager_1.Defines.ENEMY_TIME_FIRE_BASE;
            cpm.SetInfo(enemy_veloc, health, time_fire, enemy_percent_fire, _this);
        });
    };
    GameManager.prototype.ShowGameEnd = function (is_win) {
        this.nodeGameLose.active = false;
        this.nodeGameWin.active = false;
        this.state = Enum_1.GAME_STATE.END;
        if (is_win) {
            this.nodeGameWin.active = true;
        }
        else {
            this.nodeGameLose.active = true;
        }
        this.lblScoreEnd.string = 'Score: ' + this.score.toString();
        this.ShowNodeWithState();
    };
    GameManager.prototype.OnTouchStart = function () {
        this.state = Enum_1.GAME_STATE.LEVEL;
        this.ShowNodeWithState();
    };
    GameManager.prototype.OnTouchEasy = function () {
        this.state = Enum_1.GAME_STATE.LEVEL_INFO;
        this.ShowNodeWithState();
        this.level = 1;
        this.ShowInfoWithLevel();
    };
    GameManager.prototype.OnTouchNormal = function () {
        this.state = Enum_1.GAME_STATE.LEVEL_INFO;
        this.ShowNodeWithState();
        this.level = 2;
        this.ShowInfoWithLevel();
    };
    GameManager.prototype.OnTouchHard = function () {
        this.state = Enum_1.GAME_STATE.LEVEL_INFO;
        this.ShowNodeWithState();
        this.level = 3;
        this.ShowInfoWithLevel();
    };
    GameManager.prototype.OnTouchBack = function () {
        this.state = Enum_1.GAME_STATE.LEVEL;
        this.ShowNodeWithState();
    };
    GameManager.prototype.OnTouchPlay = function () {
        this.state = Enum_1.GAME_STATE.GAME;
        this.ShowNodeWithState();
        this.SetUpGameWithLevel();
    };
    var GameManager_1;
    GameManager.Defines = new GlobalDefines_1.default();
    __decorate([
        property(Player_1.default)
    ], GameManager.prototype, "player", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeEnemy", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeBullet", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeBulletEnemy", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "prefabEnemy", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "prefabBullet", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "prefabBulletEnemy", void 0);
    __decorate([
        property(cc.Label)
    ], GameManager.prototype, "lblScore", void 0);
    __decorate([
        property([cc.Node])
    ], GameManager.prototype, "nodeHealthArr", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeStart", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeLevel", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeLevelInfo", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeGame", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeEnd", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "infoLv1", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "infoLv2", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "infoLv3", void 0);
    __decorate([
        property(cc.Label)
    ], GameManager.prototype, "lblTimer", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeGameWin", void 0);
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "nodeGameLose", void 0);
    __decorate([
        property(cc.Label)
    ], GameManager.prototype, "lblScoreEnd", void 0);
    GameManager = GameManager_1 = __decorate([
        ccclass
    ], GameManager);
    return GameManager;
}(cc.Component));
exports.default = GameManager;

cc._RF.pop();