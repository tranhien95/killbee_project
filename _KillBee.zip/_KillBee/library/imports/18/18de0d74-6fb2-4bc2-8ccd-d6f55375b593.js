"use strict";
cc._RF.push(module, '18de010b7JLwozN1vVTdbWT', 'ScrollBG');
// scripts/ScrollBG.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameManager_1 = require("./GameManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ScrollBG = /** @class */ (function (_super) {
    __extends(ScrollBG, _super);
    function ScrollBG() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.screenHeight = 0;
        _this.childCount = 0;
        _this.scaleY = 0;
        return _this;
    }
    ScrollBG.prototype.start = function () {
        this.scaleY = this.screenHeight / this.node.children[0].getBoundingBox().height;
        for (var i = 0; i < this.node.childrenCount; i++) {
            this.node.children[i].scaleX = this.scaleY;
            this.node.children[i].y = this.screenHeight * i;
        }
        this.childCount = this.node.childrenCount;
    };
    ScrollBG.prototype.update = function (dt) {
        for (var i = 0; i < this.childCount; i++) {
            var element = this.node.children[i];
            element.y -= GameManager_1.default.Defines.BACKGROUND_SCROLLING_VELOC * dt;
            if (element.y < -this.screenHeight) {
                var top_index = this.CalculateTopIndex(i, this.childCount);
                element.y = this.screenHeight + this.node.children[top_index].y;
            }
        }
    };
    ScrollBG.prototype.CalculateTopIndex = function (cur_index, count) {
        if (cur_index == (count - 1)) {
            return 0;
        }
        return (cur_index + 1);
    };
    __decorate([
        property
    ], ScrollBG.prototype, "screenHeight", void 0);
    ScrollBG = __decorate([
        ccclass
    ], ScrollBG);
    return ScrollBG;
}(cc.Component));
exports.default = ScrollBG;

cc._RF.pop();