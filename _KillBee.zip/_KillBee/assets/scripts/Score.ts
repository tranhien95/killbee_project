// Learn TypeScript:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Prefab)
    num: cc.Prefab
    @property([cc.SpriteFrame])
    sprs: cc.SpriteFrame[] = [];
    score; 

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {
        let num1 = cc.instantiate(this.num);
        this.node.addChild(num1);
    }

    // update (dt) {}

    public SetScore(score)
    {
        this.score = score;
        let count = this.CountNumberScore(score);
        if(count == this.node.childrenCount)
        {
            this.SetScoreSprite(score);
        }
        else
        {
            for(let i = 0; i < this.node.childrenCount; i++)
            {
                this.node.children[i].x += this.node.children[0].getBoundingBox().width / 2;
            }
            let num1 = cc.instantiate(this.num);
            this.node.addChild(num1);
            num1.position = new cc.Vec2(this.node.children[0].position.x 
                - this.node.children[0].getBoundingBox().width * (this.node.childrenCount - 1), 0);            
            this.SetScoreSprite(score);
        }
    }

    CountNumberScore(score)
    {
        let count = 0;
        while(score >= 1)
        {
            score = score / 10;
            count++
        }
        return count;
    }

    SetScoreSprite(score)
    {
        let index = 0;
        while(score >= 1)
        {
            let num = score % 10;
            score = Math.floor(score / 10);
            this.node.children[index].getComponent(cc.Sprite).spriteFrame = this.sprs[num];     
            index++;
        }
    }

    public Reset()
    {
        this.node.removeAllChildren();
        let num1 = cc.instantiate(this.num);
        this.node.addChild(num1);
    }
}
