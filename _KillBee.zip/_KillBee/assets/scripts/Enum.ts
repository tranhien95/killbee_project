export enum GAME_STATE {
    START = 0,
    LEVEL = 1,
    LEVEL_INFO = 2,
    GAME,
    END
}

export enum PLAYER_STATE {
    NONE = 0,
    IDLE = 1,
    BURST = 2,
    DIE = 3
}

export enum ENEMY_STATE {
    NONE = 0,
    IDLE = 1,
    FIRE = 2,
    BURST = 3,
    DIE = 4
}

export enum COLLIDER_TAG {
    NONE = 0,
    PLAYER = 1,
    ENEMY = 2,
    BULLET = 3,
    BULLET_ENEMY = 4
}