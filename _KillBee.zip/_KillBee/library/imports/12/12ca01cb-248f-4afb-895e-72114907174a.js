"use strict";
cc._RF.push(module, '12ca0HLJI9K+4lechFJBxdK', 'Player');
// scripts/Player.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Enum_1 = require("./Enum");
var ObjectBase_1 = require("./ObjectBase");
var GameManager_1 = require("./GameManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.anim = null;
        _this.spriteMain = null;
        _this.spriteFrame = null;
        _this.keys = new Map();
        return _this;
    }
    Player.prototype.onLoad = function () {
        var physicsManager = cc.director.getPhysicsManager();
        physicsManager.enabled = true;
        this.rigid = this.node.getComponent(cc.RigidBody);
        this.collisionManager = cc.director.getCollisionManager();
        this.collisionManager.enabled = true;
        this.collisionManager.enabledDebugDraw = true;
    };
    Player.prototype.start = function () {
    };
    Player.prototype.SetInfo = function (gm) {
        this.node.active = true;
        this.spriteMain.spriteFrame = this.spriteFrame;
        this.gm = gm;
        this.state = Enum_1.PLAYER_STATE.IDLE;
        this.node.x = GameManager_1.default.Defines.PLAYER_BEGIN_POS_X;
        this.node.y = GameManager_1.default.Defines.PLAYER_BEGIN_POS_Y;
        this.health = GameManager_1.default.Defines.PLAYER_HEALTH;
    };
    Player.prototype.update = function (dt) {
        switch (this.state) {
            case Enum_1.PLAYER_STATE.NONE:
                {
                    break;
                }
            case Enum_1.PLAYER_STATE.IDLE:
                {
                    break;
                }
            case Enum_1.PLAYER_STATE.BURST:
                {
                    break;
                }
            case Enum_1.PLAYER_STATE.DIE:
                {
                    break;
                }
        }
    };
    Player.prototype.SetBurst = function () {
        var _this = this;
        this.state = Enum_1.PLAYER_STATE.BURST;
        this.anim.play(this.anim.getClips()[0].name);
        this.anim.getAnimationState(this.anim.getClips()[0].name).wrapMode = cc.WrapMode.Normal;
        var t = this;
        this.anim.on('finished', function (event) {
            if (_this.health == 0) {
                t.state = Enum_1.PLAYER_STATE.DIE;
                t.anim.stop();
                t.node.active = false;
            }
            else {
                t.spriteMain.spriteFrame = _this.spriteFrame;
                t.state = Enum_1.PLAYER_STATE.IDLE;
                _this.node.x = GameManager_1.default.Defines.PLAYER_BEGIN_POS_X;
                _this.node.y = GameManager_1.default.Defines.PLAYER_BEGIN_POS_Y;
            }
        });
    };
    Player.prototype.onCollisionEnter = function (other, sefl) {
        var num_tag = +other.getComponent(cc.BoxCollider).tag;
        if ((num_tag == Enum_1.COLLIDER_TAG.ENEMY || num_tag == Enum_1.COLLIDER_TAG.BULLET_ENEMY) && (this.state == Enum_1.PLAYER_STATE.IDLE)) {
            this.health--;
            this.gm.SetHealthNode();
            this.SetBurst();
        }
    };
    Player.prototype.MoveLeft = function () {
        this.node.x -= GameManager_1.default.Defines.PLAYER_DISTANCE_MOVE;
        this.AlwaysOnScreen();
    };
    Player.prototype.MoveRight = function () {
        this.node.x += GameManager_1.default.Defines.PLAYER_DISTANCE_MOVE;
        this.AlwaysOnScreen();
    };
    Player.prototype.MoveUp = function () {
        this.node.y += GameManager_1.default.Defines.PLAYER_DISTANCE_MOVE;
        this.AlwaysOnScreen();
    };
    Player.prototype.MoveDown = function () {
        this.node.y -= GameManager_1.default.Defines.PLAYER_DISTANCE_MOVE;
        this.AlwaysOnScreen();
    };
    Player.prototype.AlwaysOnScreen = function () {
        var width_2 = this.node.width / 2;
        var height_2 = this.node.height / 2;
        if (this.node.x + width_2 > GameManager_1.default.Defines.SCREEN_WIDTH / 2) {
            this.node.x = GameManager_1.default.Defines.SCREEN_WIDTH / 2 - width_2;
        }
        if (this.node.x - width_2 < -GameManager_1.default.Defines.SCREEN_WIDTH / 2) {
            this.node.x = width_2 - GameManager_1.default.Defines.SCREEN_WIDTH / 2;
        }
        if (this.node.y + height_2 > GameManager_1.default.Defines.SCREEN_HEIGHT / 2) {
            this.node.y = GameManager_1.default.Defines.SCREEN_HEIGHT / 2 - height_2;
        }
        if (this.node.y - height_2 < -GameManager_1.default.Defines.SCREEN_HEIGHT / 2) {
            this.node.y = height_2 - GameManager_1.default.Defines.SCREEN_HEIGHT / 2;
        }
    };
    Player.prototype.GetPosX = function () {
        return this.node.x;
    };
    Player.prototype.GetPosY = function () {
        return this.node.y;
    };
    Player.prototype.GetState = function () {
        return this.state;
    };
    __decorate([
        property(cc.Animation)
    ], Player.prototype, "anim", void 0);
    __decorate([
        property(cc.Sprite)
    ], Player.prototype, "spriteMain", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], Player.prototype, "spriteFrame", void 0);
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(ObjectBase_1.ObjectBase));
exports.default = Player;

cc._RF.pop();