const { ccclass, property } = cc._decorator;
@ccclass
export default class GlobalDefines {
    readonly PLAYER_HEALTH: number = 3;
    readonly PLAYER_BULLET_VELOC: number = 200;
    readonly PLAYER_BEGIN_POS_X: number = 0;
    readonly PLAYER_BEGIN_POS_Y: number = -217;
    readonly BACKGROUND_SCROLLING_VELOC: number = 300;
    readonly PLAYER_DISTANCE_MOVE: number = 20;

    readonly SCREEN_WIDTH: number = 512;
    readonly SCREEN_HEIGHT: number = 512;

    readonly ENEMY_DISTANCE_MOVE: number = 100;
    readonly ENEMY_MAX_HEALTH: number = 3;
    readonly ENEMY_BULLET_VELOC: number = 200;
    readonly ENEMY_TIME_FIRE_LV_1: number = 10;
    readonly ENEMY_TIME_FIRE_LV_2: number = 7;
    readonly ENEMY_TIME_FIRE_LV_3: number = 5;
    readonly ENEMY_TIME_FIRE_BASE: number = 3;
    readonly ENEMY_PERCENT_FIRE_LV_1: number = 15;
    readonly ENEMY_PERCENT_FIRE_LV_2: number = 20;
    readonly ENEMY_PERCENT_FIRE_LV_3: number = 25;
    readonly ENEMY_MAX_HEALTH_LV_1: number = 1;
    readonly ENEMY_MAX_HEALTH_LV_2: number = 2;
    readonly ENEMY_MAX_HEALTH_LV_3: number = 3;
    readonly ENEMY_VELOC_LV_1: number = 80;
    readonly ENEMY_VELOC_LV_2: number = 120;
    readonly ENEMY_VELOC_LV_3: number = 160;

    readonly SCREEN_MAX_X = 300;
    readonly SCREEN_MIN_X = -300;
    readonly SCREEN_MAX_Y = 300;
    readonly SCREEN_MIN_Y = -300;

    readonly TIMER_LV_1: number = 60;
    readonly TIMER_LV_2: number = 50;
    readonly TIMER_LV_3: number = 40;

    readonly BULLET_VELOC_LV_1: number = 50;
    readonly BULLET_VELOC_LV_2: number = 60;
    readonly BULLET_VELOC_LV_3: number = 70;
}